# dolphSol Macro
 A macro for the Roblox game "Sol's RNG", including features such as obby completion and item collection. A work in progress - BuilderDolphin

 ## Installation
 - First of all, you need to download [AutoHotKey v1.1](https://www.autohotkey.com/) (Not 2.0), and run the installer
 - Once complete, download the most recent version of dolphSol through the most recent [GitHub Release](https://github.com/BuilderDolphin/dolphSol-Macro/releases/latest) (Download source code ZIP)
 - After downloading, extract the ZIP file to your desired directory
 - You can now run dolphSol through the Main.ahk file in the folder

## Features
dolphSol has a couple of different features it is capable of. These include:
 - Automatic Obby Completion, with an option to check if it is completed in case it has to be redone
 - Automatic Item Collection, with options to set which spots to collect from if sharing a server
 - Automatic Aura Equipping, so you can always have an aura equipped without an animation to ensure the macro performs well
 - Discord Webhook support
 - Reconnecting upon disconnect
 - Setting for the VIP gamepass to compensate for the increased WalkSpeed
 - Settings importing, useful for updates

 Discord Server: https://discord.gg/DYUqwJchuV
